Nume complet: Vasyl Irymesku
Grupa: 3112a

Tematica arborelui genealogic:
Am ales familia mea reală pentru structura arborelui genealogic. Scripturile creează, populează și organizează o arhivă digitală care reprezintă membrii familiei mele pe mai multe niveluri.

Profil GitHub:
https://github.com/Vasyl090722/T-A--1.git